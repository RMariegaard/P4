package Nodes;

public class NegateNode extends Node {
    public NegateNode(int firstLinenumber){
        super(firstLinenumber);
    }


}
