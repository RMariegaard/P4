package Nodes;

public class NullNode extends Node{


    public NullNode(int firstLinenumber) {
        super(firstLinenumber);
    }

    @Override
    public String toString() {
        return "Null";
    }
}
