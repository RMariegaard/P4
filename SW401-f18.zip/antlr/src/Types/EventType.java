package Types;

public class EventType {

}
