package Types;

public class ArrayDclType {
}
