package Types;

public class StrategyType {
}
