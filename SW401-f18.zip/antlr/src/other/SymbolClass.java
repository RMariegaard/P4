package other;
import Nodes.Node;

public class SymbolClass {
    public String Name;
    public Node Node;
    public int Depth;
    public SymbolClass Var;
    public SymbolClass Level;
}

