package other;

public class APIevents {
    public String name;
    public String param;
    public String EventArg;

}
