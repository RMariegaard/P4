package other;

public abstract class Terminal {

    public String spelling;
}
